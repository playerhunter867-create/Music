# Project notes

NULL//WAVE is an original project created for local/offline music playback.

The visual design intentionally uses a generic terminal / matrix / CRT vocabulary. It does not claim affiliation with or reproduce the logo of any third-party organization.
