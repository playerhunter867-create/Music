# NullWave keeps release configuration intentionally simple.
