"""Generate a NULL//WAVE-style binary rain wallpaper.

Run:
    python tools/generate_matrix_wallpaper.py

Requires Pillow: pip install pillow
"""
from pathlib import Path
import random
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H = 1080, 1920
random.seed(115)
out = Path(__file__).resolve().parent.parent / "generated-matrix-wallpaper.png"

img = Image.new("RGB", (W, H), (3, 5, 4))
glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
draw = ImageDraw.Draw(glow)
font = ImageFont.load_default()

for x in range(20, W, 18):
    y = random.randint(-H, 0)
    length = random.randint(10, 45)
    speed = random.randint(5, 16)
    for i in range(length):
        yy = y + i * 15
        if 0 <= yy < H:
            a = max(12, int(185 * (1 - i / length)))
            draw.text((x, yy), random.choice("01"), font=font, fill=(70, 255, 95, a))
        y += speed

blur = glow.filter(ImageFilter.GaussianBlur(5))
img = Image.alpha_composite(img.convert("RGBA"), blur)
img = Image.alpha_composite(img, glow)

# Fine CRT lines.
scan = Image.new("RGBA", (W, H), (0, 0, 0, 0))
sd = ImageDraw.Draw(scan)
for y in range(0, H, 5):
    sd.line((0, y, W, y), fill=(170, 255, 190, 18), width=1)
img = Image.alpha_composite(img, scan)

img.convert("RGB").save(out, quality=95)
print(out)
