# NULL//WAVE — Offline Matrix Music Player

A native Android local-music player built in Kotlin + Jetpack Compose. The visual language is an original dark terminal / matrix aesthetic: black glass panels, white typography, green binary rain, scanlines and compact monospace controls.

> The included reference image is used only as a visual direction. The app does not copy a proprietary logo or brand identity.

## What it does

- Scans music already indexed by Android MediaStore.
- Imports MP3/AAC/FLAC/OGG/WAV and other formats supported by Media3 through the system file picker.
- Plays audio with Android Media3 / ExoPlayer.
- Background playback through `MediaSessionService`.
- Lock-screen / notification media controls are provided by Media3's media session.
- Search by title, artist and album.
- Play / pause / previous / next.
- Seek bar and elapsed / duration time.
- Shuffle and repeat.
- Local favorites persisted with SharedPreferences.
- Matrix rain + CRT scanline background rendered directly in Compose.
- No account, server or network connection is required for music playback.

## Build with GitHub Actions

1. Create an empty GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Push to `main` or `master`, or run **Actions → Build NULL//WAVE APK → Run workflow**.
4. Open the workflow run and download `NULL-WAVE-debug` for installation on a test phone.

The workflow installs Gradle 8.13 itself, so the repository does not depend on a pre-generated Gradle wrapper JAR.

## Local Android Studio build

Open the project root in Android Studio. Use JDK 17. Gradle/AGP are configured in the root build files.

## Python helper

`tools/generate_matrix_wallpaper.py` generates an optional phone wallpaper in the same visual language. Python is not required by the Android application itself; the actual player is native Kotlin because that gives Android reliable background audio, media sessions and system controls.

## Package

`com.nullwave.music`

## Version

1.0.0


## v1.0.2 — build fix

The project now compiles against **Android API 37** because the current Compose dependency set requires `compileSdk 37+`.

The GitHub Actions workflow explicitly installs `platforms;android-37` before Gradle runs. This prevents the `:app:checkDebugAarMetadata` failure caused by compiling with API 36.

### GitHub build

1. Upload the contents of this ZIP to a GitHub repository.
2. Open **Actions**.
3. Run **Build NULL//WAVE APK** manually, or push to `main`/`master`.
4. Open the completed workflow run.
5. Download **NULL-WAVE-debug** or **NULL-WAVE-release-unsigned** from Artifacts.

The app still uses target SDK 36; only the compile SDK was raised to satisfy the dependency metadata.
