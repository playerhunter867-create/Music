package com.nullwave.music

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.random.Random

private val Bg = Color(0xFF050607)
private val Panel = Color(0xCC0A0D0E)
private val White = Color(0xFFF2F5F2)
private val Muted = Color(0xFF9AA19C)
private val Matrix = Color(0xFF55FF77)
private val Line = Color(0xFF1A211D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NullWaveApp(this) }
    }
}

data class Track(
    val id: String,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long
)

@Composable
private fun NullWaveApp(context: Context) {
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var imported by remember { mutableStateOf(emptyList<Track>()) }
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Track?>(null) }
    var favoriteIds by remember { mutableStateOf(setOf<String>()) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentId by remember { mutableStateOf<String?>(null) }
    var repeat by remember { mutableStateOf(false) }
    var shuffle by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) tracks = loadDeviceTracks(context) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val added = uris.mapNotNull { uri ->
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            Track(
                id = uri.toString(), uri = uri,
                title = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "UNKNOWN FILE",
                artist = "IMPORTED",
                album = "LOCAL STORAGE",
                duration = 0L
            )
        }
        imported = (imported + added).distinctBy { it.id }
    }

    DisposableEffect(Unit) {
        val token = SessionToken(context, android.content.ComponentName(context, MusicService::class.java))
        val future: ListenableFuture<MediaController> = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(context))
        onDispose { controller?.release() }
    }

    LaunchedEffect(Unit) {
        while (true) {
            controller?.let {
                position = max(0L, it.currentPosition)
                duration = max(1L, it.duration)
                isPlaying = it.isPlaying
                currentId = it.currentMediaItem?.mediaId
            }
            delay(400)
        }
    }

    LaunchedEffect(Unit) {
        favoriteIds = context.getSharedPreferences("nullwave", Context.MODE_PRIVATE)
            .getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
    }

    LaunchedEffect(Unit) {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
            tracks = loadDeviceTracks(context)
        } else {
            permissionLauncher.launch(permission)
        }
    }

    val allTracks = (tracks + imported).distinctBy { it.id }
    val filtered = allTracks.filter {
        search.isBlank() || "${it.title} ${it.artist} ${it.album}".contains(search, ignoreCase = true)
    }

    fun playTrack(track: Track) {
        selected = track
        val c = controller ?: return
        val items = allTracks.map { it.toMediaItem() }
        val index = items.indexOfFirst { it.mediaId == track.id }.coerceAtLeast(0)
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Box(Modifier.fillMaxSize()) {
                MatrixRain(Modifier.fillMaxSize())
                ScanLines(Modifier.fillMaxSize())
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(WindowInsets.statusBars.asPaddingValues())
                        .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding())
                ) {
                    Header(
                        search = search,
                        onSearch = { search = it },
                        onImport = { picker.launch(arrayOf("audio/*")) }
                    )

                    if (allTracks.isEmpty()) {
                        EmptyState(onImport = { picker.launch(arrayOf("audio/*")) })
                    } else {
                        Text(
                            text = "// LOCAL AUDIO  •  ${filtered.size.toString().padStart(2, '0')}",
                            color = Muted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                        )
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = if (selected != null) 120.dp else 24.dp)
                        ) {
                            items(filtered, key = { it.id }) { track ->
                                TrackRow(
                                    track = track,
                                    active = currentId == track.id,
                                    playing = isPlaying && currentId == track.id,
                                    favorite = favoriteIds.contains(track.id),
                                    onClick = { playTrack(track) },
                                    onFavorite = {
                                        val next = favoriteIds.toMutableSet().apply {
                                            if (!add(track.id)) remove(track.id)
                                        }.toSet()
                                        favoriteIds = next
                                        context.getSharedPreferences("nullwave", Context.MODE_PRIVATE)
                                            .edit().putStringSet("favorites", next).apply()
                                    }
                                )
                            }
                        }
                    }

                    selected?.let { track ->
                        PlayerBar(
                            track = track,
                            isPlaying = isPlaying,
                            position = position,
                            duration = duration,
                            repeat = repeat,
                            shuffle = shuffle,
                            onPlayPause = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
                            onPrev = { controller?.seekToPreviousMediaItem() },
                            onNext = { controller?.seekToNextMediaItem() },
                            onSeek = { controller?.seekTo(it) },
                            onRepeat = {
                                repeat = !repeat
                                controller?.repeatMode = if (repeat) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
                            },
                            onShuffle = {
                                shuffle = !shuffle
                                controller?.shuffleModeEnabled = shuffle
                            },
                            onClose = { controller?.stop(); selected = null }
                        )
                    }
                }
            }
        }
    }
}

private fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id)
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build()
    ).build()

private fun loadDeviceTracks(context: Context): List<Track> {
    val result = mutableListOf<Track>()
    val resolver: ContentResolver = context.contentResolver
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION
    )
    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
    resolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        while (c.moveToNext()) {
            val id = c.getLong(idCol)
            val uri = Uri.withAppendedPath(collection, id.toString())
            result += Track(
                id = uri.toString(), uri = uri,
                title = c.getString(titleCol) ?: "UNKNOWN",
                artist = c.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "UNKNOWN ARTIST",
                album = c.getString(albumCol) ?: "UNKNOWN ALBUM",
                duration = c.getLong(durationCol)
            )
        }
    }
    return result
}

@Composable
private fun Header(search: String, onSearch: (String) -> Unit, onImport: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("NULL//WAVE", color = White, fontSize = 23.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                Text("OFFLINE AUDIO TERMINAL", color = Matrix, fontSize = 9.sp, letterSpacing = 2.sp, fontFamily = FontFamily.Monospace)
            }
            IconButton(onClick = onImport) {
                Icon(Icons.Default.FolderOpen, "Import music", tint = White)
            }
            IconButton(onClick = onImport) {
                Icon(Icons.Default.Add, "Add music", tint = Matrix)
            }
        }
        Spacer(Modifier.height(8.dp))
        Surface(color = Panel, shape = RoundedCornerShape(4.dp), modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 12.dp)) {
                Icon(Icons.Default.Search, null, tint = Muted, modifier = Modifier.size(18.dp))
                androidx.compose.foundation.text.BasicTextField(
                    value = search, onValueChange = onSearch,
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = White, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    decorationBox = { inner ->
                        if (search.isEmpty()) Text("SEARCH // TRACK / ARTIST / ALBUM", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        inner()
                    }
                )
            }
        }
    }
}

@Composable
private fun TrackRow(track: Track, active: Boolean, playing: Boolean, favorite: Boolean, onClick: () -> Unit, onFavorite: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 3.dp).clip(RoundedCornerShape(5.dp))
            .background(if (active) Color(0xCC111814) else Color(0x66101414)).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(50.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF0B100D)), contentAlignment = Alignment.Center) {
            Text(if (playing) "▶" else "01", color = Matrix, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(track.title, color = if (active) Matrix else White, maxLines = 1, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("${track.artist}  //  ${track.album}", color = Muted, maxLines = 1, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Matrix else Muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun PlayerBar(track: Track, isPlaying: Boolean, position: Long, duration: Long, repeat: Boolean, shuffle: Boolean,
                      onPlayPause: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit,
                      onRepeat: () -> Unit, onShuffle: () -> Unit, onClose: () -> Unit) {
    Surface(color = Color(0xF20A0D0E), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = White, maxLines = 1, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(track.artist, color = Matrix, maxLines = 1, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                TextButton(onClick = onClose) { Text("CLOSE", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp) }
            }
            Slider(value = position.coerceAtMost(duration).toFloat(), onValueChange = { onSeek(it.toLong()) }, valueRange = 0f..duration.toFloat(), modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, null, tint = if (shuffle) Matrix else Muted) }
                IconButton(onClick = onPrev) { Icon(Icons.Default.SkipPrevious, null, tint = White, modifier = Modifier.size(28.dp)) }
                Surface(shape = RoundedCornerShape(50), color = White, modifier = Modifier.size(52.dp).clickable(onClick = onPlayPause)) {
                    Box(contentAlignment = Alignment.Center) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Bg) }
                }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = White, modifier = Modifier.size(28.dp)) }
                IconButton(onClick = onRepeat) { Icon(Icons.Default.Repeat, null, tint = if (repeat) Matrix else Muted) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatMs(position), color = Muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("LOCAL • ${formatMs(duration)}", color = Muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun EmptyState(onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("[ NO AUDIO INDEX ]", color = Matrix, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Text("Grant audio access or import files manually.", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        Spacer(Modifier.height(18.dp))
        Surface(color = White, shape = RoundedCornerShape(3.dp), modifier = Modifier.clickable(onClick = onImport)) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.FolderOpen, null, tint = Bg, modifier = Modifier.size(17.dp))
                Text("  IMPORT AUDIO", color = Bg, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun MatrixRain(modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "matrix")
    val drift by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Restart), label = "drift")
    Canvas(modifier.alpha(0.33f)) {
        val columns = (size.width / 18f).toInt().coerceAtLeast(1)
        val chars = "01"
        for (i in 0..columns) {
            val seed = (i * 47) % 97
            val x = i * 18f + 5f
            val speed = 0.35f + (seed % 7) * 0.06f
            val start = ((seed * 23) % 700) / 700f
            val y0 = ((start + drift * speed) % 1.18f) * size.height - 100f
            val len = 5 + seed % 12
            for (j in 0 until len) {
                val y = y0 + j * 14f
                if (y in 0f..size.height) {
                    val alpha = (1f - j.toFloat() / len) * 0.8f
                    drawContext.canvas.nativeCanvas.drawText(
                        chars[(seed + j * 13) % chars.length].toString(), x, y,
                        android.graphics.Paint().apply {
                            color = android.graphics.Color.argb((alpha * 255).toInt(), 75, 255, 105)
                            textSize = 12f
                            typeface = android.graphics.Typeface.MONOSPACE
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ScanLines(modifier: Modifier) {
    Canvas(modifier.alpha(0.16f)) {
        var y = 0f
        while (y < size.height) {
            drawLine(Line, Offset(0f, y), Offset(size.width, y), 1f, cap = StrokeCap.Square)
            y += 5f
        }
    }
}

private fun formatMs(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(total / 60, total % 60)
}
