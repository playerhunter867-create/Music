# NULL//WAVE Android v1.1.0

A local music player with a dark terminal / Matrix / DedSec-inspired interface.

## Changes in v1.1.0
- Tracks shorter than **40 seconds** are not indexed or imported.
- Importing a short file shows a rejection message.
- Added **60 / 90 / 120 FPS** performance target in `SYSTEM // CONFIG`.
- The selected refresh target is persisted.
- Added a hacker-style settings menu.
- Improved Matrix/CRT presentation.
- Launcher icon uses the supplied artwork, cropped to the central character so it remains readable as an app icon.
- Media3 background playback remains enabled.

### Important about FPS
The app requests a preferred display refresh rate. Android and the phone hardware can still cap the real refresh rate; selecting 120 FPS cannot make a 60 Hz screen physically run at 120 Hz.

## Build
GitHub Actions is included in `.github/workflows/build-apk.yml`.

1. Upload the project to a GitHub repository.
2. Open **Actions**.
3. Run **Build NULL//WAVE APK**.
4. Download the `NULL-WAVE-debug` or `NULL-WAVE-release-unsigned` artifact.

## Audio rule
Only tracks with a duration of at least `00:40` are accepted.

## Tech
- Kotlin
- Jetpack Compose
- Android Media3 / ExoPlayer
- MediaSessionService
- Python asset generator
