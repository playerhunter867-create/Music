# NULL//WAVE Android v1.1.4

A local music player with a dark terminal / Matrix / DedSec-inspired interface.

## What was fixed in v1.1.4

- Fixed the GitHub Actions workflow so it **does not hard-code a ZIP filename**.
- The workflow builds the Android project directly when the repository contains `settings.gradle.kts`.
- If someone uploads a ZIP instead, the workflow automatically finds the first **valid** ZIP, validates it with `unzip -t`, extracts it, finds the Android project, and builds it.
- Corrupt ZIPs now produce a useful diagnostic instead of the misleading `End-of-central-directory signature not found` failure being hidden behind a filename.
- App version is now `1.1.4`.
- Added Android 13+ notification permission support.
- Local music playback uses Media3 / ExoPlayer with a MediaSession service for background playback.
- Tracks shorter than 00:40 are excluded.
- Matrix rain + CRT scanlines + terminal UI remain enabled.
- 60 / 90 / 120 Hz preferred display-rate setting remains available.

## Recommended GitHub layout

Upload the **contents of this ZIP**, not the ZIP itself:

```text
.github/workflows/build-apk.yml
app/
build.gradle.kts
settings.gradle.kts
gradle.properties
...
```

The workflow also supports the less convenient case where a valid project ZIP is uploaded to the repository.

## Build

1. Create a GitHub repository.
2. Upload the project files from this archive.
3. Open **Actions**.
4. Select **Build NULL//WAVE APK**.
5. Press **Run workflow**.
6. Download `NULL-WAVE-debug` for an installable debug APK.

The release artifact is unsigned and is intended for later signing before public distribution.

## Audio

The app indexes local music and accepts imported audio files with a duration of at least 00:40.

## Tech

- Kotlin
- Jetpack Compose
- Android Media3 / ExoPlayer 1.11.0
- MediaSessionService
- Python asset generator


## v1.1.4 build fix
- Fixed Compose Android `nativeCanvas` import.
- Added explicit `ui-graphics` dependency.
- GitHub Actions installs/validates Android API 36 before Gradle build.
