# NULL//WAVE v1.1.4 — Build fix

The previous build failed at `:app:checkDebugAarMetadata` because the
2026.08.00 Compose BOM resolves Compose 1.12.x, which requires compileSdk 37
and AGP 9.x.

This release deliberately uses the stable Compose 1.11.4 line via
Compose BOM `2026.06.01`, keeping the existing AGP 8.13.2 toolchain.

Additional alignment:
- `compileSdk = 36`
- `compileSdkExtension = 1` (Android API 36.1)
- Build Tools `36.1.0`
- JDK 17
- Gradle 8.13
- AGP 8.13.2

The GitHub Actions workflow installs the required SDK packages before the
debug and release builds.


### v1.2.0 compile fixes
`Player.REPEAT_MODE_*` now has the correct `androidx.media3.common.Player` import. The invalid `Window.setFrameRate()` call was removed; Android's `WindowManager.LayoutParams.preferredRefreshRate` is used instead.
