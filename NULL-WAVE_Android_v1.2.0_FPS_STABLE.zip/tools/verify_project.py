#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(__file__).resolve().parents[1]
src = root / "app/src/main/java/com/nullwave/music/MainActivity.kt"
gradle = root / "app/build.gradle.kts"

errors = []
text = src.read_text(encoding="utf-8")
gtext = gradle.read_text(encoding="utf-8")

required = [
    "import androidx.media3.common.Player",
    "Player.REPEAT_MODE_ONE",
    "MIN_DURATION_MS = 40_000L",
    "preferredRefreshRate",
    "AnimatedVisibility",
]
for token in required:
    if token not in text:
        errors.append(f"missing required token: {token}")

for bad in ["window.setFrameRate", "Window.FRAME_RATE_COMPATIBILITY_DEFAULT", "Player.REPEAT_MODE_ALL"]:
    if bad in text:
        errors.append(f"obsolete/undesired API or mode found: {bad}")

if 'versionName = "1.2.0"' not in gtext:
    errors.append("unexpected app version")

if errors:
    print("NULL//WAVE validation FAILED")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print("NULL//WAVE validation OK")
