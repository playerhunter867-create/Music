package com.nullwave.music

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.random.Random

private val Bg = Color(0xFF050607)
private val Panel = Color(0xCC0A0D0E)
private val White = Color(0xFFF2F5F2)
private val Muted = Color(0xFF9AA19C)
private val Matrix = Color(0xFF55FF77)
private val Line = Color(0xFF1A211D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NullWaveApp(this) }
    }
}

data class Track(
    val id: String,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long
)

@Composable
private fun NullWaveApp(context: Context) {
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var imported by remember { mutableStateOf(emptyList<Track>()) }
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Track?>(null) }
    var favoriteIds by remember { mutableStateOf(setOf<String>()) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentId by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("nullwave", Context.MODE_PRIVATE) }
    var repeat by remember { mutableStateOf(prefs.getBoolean("repeat", false)) }
    var shuffle by remember { mutableStateOf(prefs.getBoolean("shuffle", false)) }
    var targetFps by remember { mutableStateOf(prefs.getInt("fps", 90).coerceIn(60, 120)) }
    var matrixIntensity by remember { mutableStateOf(prefs.getFloat("matrix_intensity", 0.33f).coerceIn(0.10f, 0.55f)) }
    var matrixSpeed by remember { mutableStateOf(prefs.getFloat("matrix_speed", 1.0f).coerceIn(0.5f, 1.8f)) }

    // Request the device/display to run the UI at the user's selected refresh target.
    // Android may choose a lower rate if the hardware does not support it.
    LaunchedEffect(targetFps) {
        windowSetPreferredFrameRate(context, targetFps.toFloat())
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) tracks = loadDeviceTracks(context) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        var rejected = 0
        val added = uris.mapNotNull { uri ->
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            val meta = readAudioMetadata(context, uri)
            if (meta.duration < MIN_DURATION_MS) {
                rejected++
                return@mapNotNull null
            }
            Track(
                id = uri.toString(), uri = uri,
                title = meta.title ?: uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "UNKNOWN FILE",
                artist = meta.artist ?: "IMPORTED",
                album = meta.album ?: "LOCAL STORAGE",
                duration = meta.duration
            )
        }
        imported = (imported + added).distinctBy { it.id }
        if (rejected > 0) {
            Toast.makeText(context, "$rejected file(s) ignored — minimum length is 00:40", Toast.LENGTH_SHORT).show()
        }
    }

    DisposableEffect(Unit) {
        val token = SessionToken(context, android.content.ComponentName(context, MusicService::class.java))
        val future: ListenableFuture<MediaController> = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(context))
        onDispose { controller?.release() }
    }

    LaunchedEffect(controller) {
        controller?.let {
            it.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            it.shuffleModeEnabled = shuffle
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            controller?.let {
                position = max(0L, it.currentPosition)
                duration = max(1L, it.duration)
                isPlaying = it.isPlaying
                currentId = it.currentMediaItem?.mediaId
                repeat = it.repeatMode == Player.REPEAT_MODE_ONE
                shuffle = it.shuffleModeEnabled
            }
            delay(400)
        }
    }

    LaunchedEffect(Unit) {
        favoriteIds = context.getSharedPreferences("nullwave", Context.MODE_PRIVATE)
            .getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
            tracks = loadDeviceTracks(context)
        } else {
            permissionLauncher.launch(permission)
        }
    }

    val allTracks = (tracks + imported).distinctBy { it.id }
    val filtered = allTracks.filter {
        search.isBlank() || "${it.title} ${it.artist} ${it.album}".contains(search, ignoreCase = true)
    }

    fun playTrack(track: Track) {
        selected = track
        val c = controller ?: return
        val items = allTracks.map { it.toMediaItem() }
        val index = items.indexOfFirst { it.mediaId == track.id }.coerceAtLeast(0)
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Box(Modifier.fillMaxSize()) {
                MatrixRain(Modifier.fillMaxSize(), matrixIntensity, matrixSpeed)
                ScanLines(Modifier.fillMaxSize())
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(WindowInsets.statusBars.asPaddingValues())
                        .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding())
                ) {
                    Header(
                        search = search,
                        onSearch = { search = it },
                        onImport = { picker.launch(arrayOf("audio/*")) },
                        onSettings = { showSettings = true },
                        targetFps = targetFps
                    )

                    if (allTracks.isEmpty()) {
                        EmptyState(onImport = { picker.launch(arrayOf("audio/*")) })
                    } else {
                        Text(
                            text = "// LOCAL AUDIO  •  ${filtered.size.toString().padStart(2, '0')}",
                            color = Muted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                        )
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = if (selected != null) 120.dp else 24.dp)
                        ) {
                            items(filtered, key = { it.id }) { track ->
                                TrackRow(
                                    track = track,
                                    active = currentId == track.id,
                                    playing = isPlaying && currentId == track.id,
                                    favorite = favoriteIds.contains(track.id),
                                    onClick = { playTrack(track) },
                                    onFavorite = {
                                        val next = favoriteIds.toMutableSet().apply {
                                            if (!add(track.id)) remove(track.id)
                                        }.toSet()
                                        favoriteIds = next
                                        context.getSharedPreferences("nullwave", Context.MODE_PRIVATE)
                                            .edit().putStringSet("favorites", next).apply()
                                    }
                                )
                            }
                        }
                    }

                    AnimatedVisibility(
                        visible = selected != null,
                        enter = slideInVertically(
                            initialOffsetY = { fullHeight -> fullHeight },
                            animationSpec = tween(320)
                        ) + fadeIn(animationSpec = tween(220)),
                        exit = slideOutVertically(
                            targetOffsetY = { fullHeight -> fullHeight },
                            animationSpec = tween(260)
                        ) + fadeOut(animationSpec = tween(180))
                    ) {
                        selected?.let { track ->
                            PlayerBar(
                                track = track,
                                isPlaying = isPlaying,
                                position = position,
                                duration = duration,
                                repeat = repeat,
                                shuffle = shuffle,
                                onPlayPause = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
                                onPrev = { controller?.seekToPreviousMediaItem() },
                                onNext = { controller?.seekToNextMediaItem() },
                                onSeek = { controller?.seekTo(it) },
                                onRepeat = {
                                    repeat = !repeat
                                    prefs.edit().putBoolean("repeat", repeat).apply()
                                    controller?.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                                },
                                onShuffle = {
                                    shuffle = !shuffle
                                    prefs.edit().putBoolean("shuffle", shuffle).apply()
                                    controller?.shuffleModeEnabled = shuffle
                                },
                                onClose = { controller?.stop(); selected = null }
                            )
                        }
                    }
                }

                if (showSettings) {
                    SettingsDialog(
                        targetFps = targetFps,
                        matrixIntensity = matrixIntensity,
                        matrixSpeed = matrixSpeed,
                        onFpsSelected = { fps ->
                            targetFps = fps
                            prefs.edit().putInt("fps", fps).apply()
                        },
                        onMatrixIntensityChanged = { value ->
                            matrixIntensity = value
                            prefs.edit().putFloat("matrix_intensity", value).apply()
                        },
                        onMatrixSpeedChanged = { value ->
                            matrixSpeed = value
                            prefs.edit().putFloat("matrix_speed", value).apply()
                        },
                        onDismiss = { showSettings = false }
                    )
                }
            }
        }
    }
}

private fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id)
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build()
    ).build()

private fun loadDeviceTracks(context: Context): List<Track> {
    val result = mutableListOf<Track>()
    val resolver: ContentResolver = context.contentResolver
    val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION
    )
    val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= $MIN_DURATION_MS"
    resolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
        val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
        val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        while (c.moveToNext()) {
            val id = c.getLong(idCol)
            val uri = Uri.withAppendedPath(collection, id.toString())
            result += Track(
                id = uri.toString(), uri = uri,
                title = c.getString(titleCol) ?: "UNKNOWN",
                artist = c.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "UNKNOWN ARTIST",
                album = c.getString(albumCol) ?: "UNKNOWN ALBUM",
                duration = c.getLong(durationCol)
            )
        }
    }
    return result
}

@Composable
private fun Header(
    search: String,
    onSearch: (String) -> Unit,
    onImport: () -> Unit,
    onSettings: () -> Unit,
    targetFps: Int
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("NULL//WAVE", color = White, fontSize = 23.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                Text("DEDSEC AUDIO NODE  //  ${targetFps}HZ TARGET", color = Matrix, fontSize = 9.sp, letterSpacing = 1.7.sp, fontFamily = FontFamily.Monospace)
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, "Settings", tint = White)
            }
            IconButton(onClick = onImport) {
                Icon(Icons.Default.Add, "Add music", tint = Matrix)
            }
        }
        Spacer(Modifier.height(8.dp))
        Surface(color = Panel, shape = RoundedCornerShape(4.dp), modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 12.dp)) {
                Icon(Icons.Default.Search, null, tint = Muted, modifier = Modifier.size(18.dp))
                androidx.compose.foundation.text.BasicTextField(
                    value = search, onValueChange = onSearch,
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = White, fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    decorationBox = { inner ->
                        if (search.isEmpty()) Text("SEARCH // TRACK / ARTIST / ALBUM", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        inner()
                    }
                )
            }
        }
    }
}

@Composable
private fun TrackRow(track: Track, active: Boolean, playing: Boolean, favorite: Boolean, onClick: () -> Unit, onFavorite: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 3.dp).clip(RoundedCornerShape(5.dp))
            .background(if (active) Color(0xCC111814) else Color(0x66101414)).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(50.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF0B100D)), contentAlignment = Alignment.Center) {
            Text(if (playing) "▶" else "01", color = Matrix, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(track.title, color = if (active) Matrix else White, maxLines = 1, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("${track.artist}  //  ${track.album}", color = Muted, maxLines = 1, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Matrix else Muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun PlayerBar(track: Track, isPlaying: Boolean, position: Long, duration: Long, repeat: Boolean, shuffle: Boolean,
                      onPlayPause: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit,
                      onRepeat: () -> Unit, onShuffle: () -> Unit, onClose: () -> Unit) {
    Surface(color = Color(0xF20A0D0E), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = White, maxLines = 1, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text(track.artist, color = Matrix, maxLines = 1, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                TextButton(onClick = onClose) { Text("CLOSE", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp) }
            }
            Slider(value = position.coerceAtMost(duration).toFloat(), onValueChange = { onSeek(it.toLong()) }, valueRange = 0f..duration.toFloat(), modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, null, tint = if (shuffle) Matrix else Muted) }
                IconButton(onClick = onPrev) { Icon(Icons.Default.SkipPrevious, null, tint = White, modifier = Modifier.size(28.dp)) }
                Surface(shape = RoundedCornerShape(50), color = White, modifier = Modifier.size(52.dp).clickable(onClick = onPlayPause)) {
                    Box(contentAlignment = Alignment.Center) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Bg) }
                }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = White, modifier = Modifier.size(28.dp)) }
                IconButton(onClick = onRepeat) { Icon(Icons.Default.Repeat, null, tint = if (repeat) Matrix else Muted) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatMs(position), color = Muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text("LOCAL • ${formatMs(duration)}", color = Muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun EmptyState(onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("[ NO AUDIO INDEX ]", color = Matrix, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Text("Only audio files 00:40 or longer are accepted.", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        Spacer(Modifier.height(18.dp))
        Surface(color = White, shape = RoundedCornerShape(3.dp), modifier = Modifier.clickable(onClick = onImport)) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.FolderOpen, null, tint = Bg, modifier = Modifier.size(17.dp))
                Text("  IMPORT AUDIO", color = Bg, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingsDialog(
    targetFps: Int,
    matrixIntensity: Float,
    matrixSpeed: Float,
    onFpsSelected: (Int) -> Unit,
    onMatrixIntensityChanged: (Float) -> Unit,
    onMatrixSpeedChanged: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = Color(0xFF080B09),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().padding(20.dp)
        ) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SYSTEM // CONFIG", color = White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("NULL-WAVE PERFORMANCE", color = Matrix, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, null, tint = Muted)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text("TARGET FRAME RATE", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf(60, 90, 120).forEach { fps ->
                        Surface(
                            color = if (fps == targetFps) White else Color(0xFF111613),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.weight(1f).clickable { onFpsSelected(fps) }
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("$fps", color = if (fps == targetFps) Bg else White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("FPS", color = if (fps == targetFps) Bg else Matrix, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Android treats this as a preferred display rate. Actual FPS depends on the phone panel and power mode.",
                    color = Muted, fontFamily = FontFamily.Monospace, fontSize = 9.sp, lineHeight = 13.sp
                )
                Spacer(Modifier.height(14.dp))
                Text("MATRIX INTENSITY  //  ${(matrixIntensity * 100).toInt()}%", color = Matrix, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                Slider(
                    value = matrixIntensity,
                    onValueChange = onMatrixIntensityChanged,
                    valueRange = 0.10f..0.55f,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("RAIN SPEED  //  ${"%.1fx".format(matrixSpeed)}", color = Matrix, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                Slider(
                    value = matrixSpeed,
                    onValueChange = onMatrixSpeedChanged,
                    valueRange = 0.5f..1.8f,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Text("PLAYBACK  //  REPEAT = CURRENT TRACK", color = Matrix, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                Text("The repeat key always loops the active track.", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                Spacer(Modifier.height(12.dp))
                Text("AUDIO FILTER  //  MIN 00:40", color = Matrix, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                Text("Short clips are rejected during indexing/import.", color = Muted, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
            }
        }
    }
}

private const val MIN_DURATION_MS = 40_000L

private data class AudioMeta(val title: String?, val artist: String?, val album: String?, val duration: Long)

private fun readAudioMetadata(context: Context, uri: Uri): AudioMeta {
    val mmr = android.media.MediaMetadataRetriever()
    return try {
        mmr.setDataSource(context, uri)
        AudioMeta(
            title = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE),
            artist = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST),
            album = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM),
            duration = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        )
    } catch (_: Exception) {
        AudioMeta(null, null, null, 0L)
    } finally {
        try { mmr.release() } catch (_: Exception) {}
    }
}

private fun windowSetPreferredFrameRate(context: Context, fps: Float) {
    val activity = context as? android.app.Activity ?: return
    // Window.setFrameRate() is not a Window API. Use the supported
    // WindowManager.LayoutParams preferred refresh-rate hint instead.
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val params = activity.window.attributes
        params.preferredRefreshRate = fps
        activity.window.attributes = params
    }
}

@Composable
private fun MatrixRain(modifier: Modifier, intensity: Float, speed: Float) {
    val transition = rememberInfiniteTransition(label = "matrix")
    val cycleMs = (12000f / speed).toInt().coerceIn(6500, 24000)
    val drift by transition.animateFloat(
        0f,
        1f,
        infiniteRepeatable(
            tween(cycleMs, easing = LinearEasing),
            RepeatMode.Restart
        ),
        label = "drift"
    )

    // Keep the animation draw-only: no Paint allocations and no Compose
    // recomposition for every Matrix character on every frame.
    val matrixModifier = modifier
        .alpha(intensity)
        .drawWithCache {
            val columns = (size.width / 18f).toInt().coerceAtLeast(1)
            val xPositions = FloatArray(columns + 1)
            val seeds = IntArray(columns + 1)
            for (i in 0..columns) {
                xPositions[i] = i * 18f + 5f
                seeds[i] = (i * 47) % 97
            }

            val paint = android.graphics.Paint(
                android.graphics.Paint.ANTI_ALIAS_FLAG
            ).apply {
                textSize = 12f
                typeface = android.graphics.Typeface.MONOSPACE
                isSubpixelText = true
            }

            onDrawBehind {
                val chars = "01"
                val height = size.height

                for (i in xPositions.indices) {
                    val seed = seeds[i]
                    val columnSpeed = 0.35f + (seed % 7) * 0.06f
                    val start = ((seed * 23) % 700) / 700f
                    val y0 = ((start + drift * columnSpeed) % 1.18f) * height - 100f
                    val len = 5 + seed % 12

                    for (j in 0 until len) {
                        val y = y0 + j * 14f
                        if (y in 0f..height) {
                            val alpha = (1f - j.toFloat() / len) * 0.8f
                            paint.alpha = (alpha * 255f).toInt().coerceIn(0, 255)
                            val charIndex = (seed + j * 13) % chars.length
                            drawContext.canvas.nativeCanvas.drawText(
                                chars,
                                charIndex,
                                charIndex + 1,
                                xPositions[i],
                                y,
                                paint
                            )
                        }
                    }
                }
            }
        }

    androidx.compose.foundation.layout.Spacer(matrixModifier)
}

@Composable
private fun ScanLines(modifier: Modifier) {
    // Build the scanline geometry once for the current size instead of
    // allocating hundreds of draw calls/objects during every animation frame.
    val scanlineModifier = modifier
        .alpha(0.16f)
        .drawWithCache {
            val path = android.graphics.Path()
            var y = 0f
            while (y < size.height) {
                path.moveTo(0f, y)
                path.lineTo(size.width, y)
                y += 5f
            }

            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(26, 33, 29)
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = 1f
            }

            onDrawBehind {
                drawContext.canvas.nativeCanvas.drawPath(path, paint)
            }
        }

    androidx.compose.foundation.layout.Spacer(scanlineModifier)
}

private fun formatMs(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(total / 60, total % 60)
}
